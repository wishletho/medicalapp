enum GalleryFileTypes { CANCEL, CAMERA, GALLERY }

enum EncounterTypeEnum { REPORTS, PRESCRIPTIONS, OTHERS }

enum EncounterTypeValues { PROBLEM, OBSERVATION, NOTE, PRESCRIPTION }

enum PaymentMethod { Woocommerce, RazorPay }
