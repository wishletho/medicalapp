import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:nb_utils/nb_utils.dart';

class DefaultFirebaseConfig {
  static String iosAppId = '1:1030276386601:ios:c8f9a1a5df8361a83ab138';
  static String androidAppID = '1:1030276386601:android:41c50003711161d13ab138';

  static FirebaseOptions get platformOptions {
    if (isMobile)
      return FirebaseOptions(
        appId: isApple ? iosAppId : androidAppID,
        apiKey: 'AIzaSyAwmwUrbDgXy47B7uu5m_5-I42c3v4TFNE',
        projectId: 'kivicare-5d319',
        messagingSenderId: '1030276386601',
        storageBucket: 'kivicare-5d319.appspot.com',
      );
    else
      throw UnsupportedError(
        'DefaultFirebaseOptions have not been configured for selected platform '
      );
  }
}
