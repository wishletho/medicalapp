class WeekDaysModel {
  String? name;
  String? value;
  bool? isSelected;

  WeekDaysModel({this.name, this.value, this.isSelected});
}
