class DemoLoginModel {
  String? loginTypeImage;
  Function()? onTap;

  DemoLoginModel({this.loginTypeImage, this.onTap});
}
