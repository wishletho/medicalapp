class WalkThroughModel {
  String? image;
  String? title;
  String? subTitle;

  WalkThroughModel({this.image, this.title, this.subTitle});
}
